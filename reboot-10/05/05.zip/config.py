# coding=utf-8

# name='xxx'

def hello():
    print 'hello'


if __name__=='__main__':
    print '111'
    print 'homework'
# config = {
#     'password':'xxx',
#     'host':'jjj'
# }



