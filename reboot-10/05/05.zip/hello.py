

name = 'reboot'
def hello_world():
    print 'hello world!'

if __name__ == '__main__':
    print 'chifan'
