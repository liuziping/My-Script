Flask
Flask-JSONRPC
MySQL-python 
requests 
